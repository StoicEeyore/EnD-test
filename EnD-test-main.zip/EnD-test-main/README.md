# Emperor and Deities
 Major Overhaul of literary everything, if you are not satisfied with how civ 5 portrays human civilizations, you ought to try this mod!

 The Mod is WIP so civs dont have their unique features currently and late game(info age) kinda sucks.

 Credit to 
 Buckeeter aka Wadaling for making full vector icons and tile sets.
 EmperorPenguin for help with proofreading, bug fixing advices
 FastDoubloon115_ for help with playtesting

 Special thanks to:
 (I cant remember their name so I will list out their works)
 Authors of Deciv and Deciv redux, Outlaw of waste, Alpha frontier, Leaders mission 1 and 2, CS reworked, Rek mod, The great unciv rework and the rest of the community. 
 ---
 Great mods and bad mods both pushed me to this point. Its all your fault!

 Feedback goes to official unciv discord's Emperors and Deities thread, or just open a issue here!

 Feel free to translate this mod and send them to author
 Simpified Chinese Translation done by CX61 himself
 Russian Translation done by Nori_Bori from discord with help of Genemi AI


